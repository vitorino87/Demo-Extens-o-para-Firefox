document.addEventListener('DOMContentLoaded',function(){
	document.querySelector('button').addEventListener('click', testContentScript);	
});

function testContentScript(){
	var p = document.getElementById("idFormDadosEntradaSaida:horaEntrada").value;
	console.log(p);
}